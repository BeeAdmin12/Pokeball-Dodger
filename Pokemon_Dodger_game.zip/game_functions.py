import sys

import pygame

from pokeballs import Pokeballs


def check_events(pokemon):
	"""Check events that happen in game."""
	for event in pygame.event.get():
		if event.type == pygame.QUIT:
			sys.exit()
		elif event.type == pygame.KEYDOWN:
			check_keydown_events(event, pokemon)
		elif event.type == pygame.KEYUP:
			check_keyup_events(event, pokemon)
			
			
def check_keydown_events(event, pokemon):
	"""Check for keys being pressed down."""
	if event.key == pygame.K_UP:
		pokemon.up = True
	elif event.key == pygame.K_DOWN:
		pokemon.down = True
	elif event.key == pygame.K_RIGHT:
		pokemon.right = True
	elif event.key == pygame.K_LEFT:
		pokemon.left = True
	elif event.key == pygame.K_q:
		sys.exit()
		
		
def check_keyup_events(event, pokemon):
	"""Chekc for key up events."""
	if event.key == pygame.K_UP:
		pokemon.up = False
	elif event.key == pygame.K_DOWN:
		pokemon.down = False
	elif event.key == pygame.K_RIGHT:
		pokemon.right = False
	elif event.key == pygame.K_LEFT:
		pokemon.left = False
			
			
def update_screen(ai_settings, screen, pokemon, pokeballs):
	"""Update the screen."""
	#Screen background color.
	screen.fill(ai_settings.bg_color)
	
	#Draw squirtle on to screen.
	pokemon.blitme()
	
	#draw group of pokeballs
	pokeballs.draw(screen)

	#Display the screen.
	pygame.display.flip()
	
	
def make_pokeball(ai_settings, screen, pokeballs):
	"""Make a pokeball that belongs to the group."""
	pokeball = Pokeballs(ai_settings, screen)
	
	if len(pokeballs) < 5:
		pokeballs.add(pokeball)
	
	
def update_pokeballs(ai_settings, screen, pokeballs):
	"""Updates pokeballs."""
	make_pokeball(ai_settings, screen, pokeballs)
	pokeballs.update()
	check_pokeballs_hit_edge(ai_settings, screen, pokeballs)
	
	
def check_pokeballs_hit_edge(ai_settings, screen, pokeballs):
	"""Update what happens to the pokeballs."""
	screen_rect = screen.get_rect()
	for pokeball in pokeballs.sprites():
		if pokeball.rect.bottom >= screen_rect.bottom:
			pokeballs.remove(pokeball)
			break
