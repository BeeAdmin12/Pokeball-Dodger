import pygame

class Pokemon():
	
	def __init__ (self, ai_settings, screen):
		"""Make character and show it on screen."""
		self.screen = screen
		self.ai_settings = ai_settings
		
		#load the image and get its rect.
		self.image = pygame.image.load('images/Squirtle.bmp') #load the image
		self.rect = self.image.get_rect() #get image rect
		self.screen_rect = screen.get_rect() #get screen rect
		
		#Image positioning
		self.rect.centerx = self.screen_rect.centerx 
		self.rect.centery = self.screen_rect.centery
		
		#get exact positioning of the pokemon
		self.centerx = float(self.rect.centerx)
		self.centery = float(self.rect.centery)
		
		#Movement flags.
		self.up = False
		self.down = False
		self.left = False
		self.right = False
		
		
	def update(self):
		"""Update the positioning of the pokemon."""
		if self.up and self.rect.top >= self.screen_rect.top:
			self.centery -= self.ai_settings.pokemon_speed
		if self.down and self.rect.bottom <= self.screen_rect.bottom:
			self.centery += self.ai_settings.pokemon_speed
			
		self.rect.centery = self.centery
		
		if self.right and self.rect.right <= self.screen_rect.right:
			self.centerx += self.ai_settings.pokemon_speed
		if self.left and self.rect.left >= self.screen_rect.left:
			self.centerx -= self.ai_settings.pokemon_speed
			
		self.rect.centerx = self.centerx
		

	def blitme(self):
		"""Draw the image at its current location."""
		self.screen.blit(self.image, self.rect)

