import pygame
from pygame.sprite import Sprite
import random

class Pokeballs(Sprite):
	
	def __init__ (self, ai_settings, screen):
		"""Make character and show it on screen."""
		super (). __init__ ()
		self.screen = screen
		self.ai_settings = ai_settings
		
		#load the image and get its rect.
		self.image = pygame.image.load('images/pokeball.bmp') #load the image
		self.rect = self.image.get_rect() #get image rect
		self.screen_rect = screen.get_rect() #get screen rect
		
		#Image positioning
		self.starting_pos()
		
		#Get exact positioning
		self.centery = float(self.rect.centery) #???
		self.centerx = float(self.rect.centerx) #???
		
		#Movement flags
		self.down = True
		
		self.speed = ai_settings.pokeball_speed
		
	def update(self):
		"""Update positioning of pokeballs."""
		if self.down:
			self.centery += self.speed
			
		self.rect.centery = self.centery
		
		if True:
			self.centerx += self.speed
			
		self.rect.centerx = self.centerx
		

	def blitme(self):
		"""Draw the image at its current location."""
		self.screen.blit(self.image, self.rect)
		
		
	def starting_pos(self):
		"""To get the starting position for a pokeball"""
		self.rect.centerx = randint(16, self.screen_rect.right - 16)
		self.rect.centery = randint(self.screen_rect.top + 16,
									self.screen_rect.bottom - 16)
		
		outcomes = ['self.rect.centerx', 'self.rect.centery']
		starting_pos = random.choice(outcomes)
		
		return starting_pos
