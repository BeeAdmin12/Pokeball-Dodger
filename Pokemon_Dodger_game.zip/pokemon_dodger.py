import sys

import pygame
from pygame.sprite import Group

from settings import Settings
import game_functions as gf
from pokemon_image import Pokemon

def run_game():
	
	pygame.init()
	ai_settings = Settings()
	screen = pygame.display.set_mode((ai_settings.screen_width,
										ai_settings.screen_height))
	pygame.display.set_caption("Pokemon Dodger")
	
	pokemon = Pokemon(ai_settings, screen)
	
	pokeballs = Group()

	while True:
	
		gf.check_events(pokemon)
		pokemon.update()
		gf.update_pokeballs(ai_settings, screen, pokeballs)
		gf.update_screen(ai_settings, screen, pokemon, pokeballs)
				
run_game()
