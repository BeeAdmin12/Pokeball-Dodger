class Settings():
	"""A class for the settings of Pokemon Dodger."""
	
	def __init__ (self):
		"""Initialize settings from Pokemon Dodger."""
		#Screen settings.
		self.screen_width = 800
		self.screen_height = 800
		self.bg_color = (0, 50, 0)

		#Pokemon settings.
		self.pokemon_speed = 1
		
		#Pokeball speed.
		self.pokeball_speed = 1.5
